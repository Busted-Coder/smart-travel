<div class="row">
	<div class="col-sm-12">
	<a class="btn btn-primary">Total Records : <?php echo count($info); ?></a>
	</div>
</div>
