<div class='container'>
	<h2>Success	
	</h2>
	<p>
		Your account has been created!
	</p>
</div>