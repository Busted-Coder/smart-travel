<div class="container">
	<div class="col-sm-10 col-sm-offset-2">
		
		<h1>Add Bus Pre-Req(Cam-2)</h1>
		<form action="<?php echo site_url('index.php/bus/add_cam2') ?>" method="post" class="form-horizontal">
			<div class="form-group">
				<div class="col-sm-4">
					<div><b>Cam Model</b></div>
					<input name="model" type="text" placeholder="Model #/Name" class="form-control" required>
				</div>
			</div>
			
			<div class="form-group">
				<div class="col-sm-4">
					<input type="submit" class="btn btn-danger" value="Submit">
				</div>
			</div>
			</div>
		</form>
	</div>
</div>