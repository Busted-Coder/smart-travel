<div class="container">
	<div class="col-sm-10 col-sm-offset-2">
		
		<h1>Add Bus Pre-Req(Tracker)</h1>
		<form action="<?php echo site_url('bus/tracker') ?>" method="post" class="form-horizontal">
			<div class="form-group">
				<div class="col-sm-4">
					<a href="<?php echo site_url('index.php/bus/add_tracker') ?>" class="btn btn-danger">Add Tracker</a>
				</div>
			</div>
		</form>
	</div>
</div>