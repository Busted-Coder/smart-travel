<h1>uploaded</h1>
<a href="<?php echo site_url('image') ?>">Upload Another</a>