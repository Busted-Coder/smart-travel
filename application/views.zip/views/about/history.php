<section class="section-height-800 breadcrumb-modern rd-parallax context-dark bg-gray-darkest text-lg-left">
          <div data-speed="0.2" data-type="media" data-url="<?php echo PATH; ?>images/backgrounds/background-01-1920x900.jpg" class="rd-parallax-layer"></div>
          <div data-speed="0" data-type="html" class="rd-parallax-layer">
            <div class="bg-primary-chathams-blue-reverse">
              <div class="shell section-top-57 section-bottom-30 section-md-top-210 section-lg-top-260">
                <div class="veil reveal-md-block">
                  <h1 class="text-bold">About us</h1>
                </div>
                <ul class="list-inline list-inline-icon list-inline-icon-type-1 list-inline-icon-extra-small list-inline-icon-white p offset-top-30 offset-md-top-40 offset-lg-top-125">
                  <li><a href="<?php echo base_url();?>index.php/Welcome/index" class="text-white">Home</a></li>
                  <li><a href="our-history.html" class="text-white">About us</a></li>
                 
                </ul>
              </div>
            </div>
          </div>
        </section>
      </header>
<html lang="en" class="wide wow-animation smoothscroll scrollTo">
  
        
      <!-- Page Contents-->
      <main class="page-content">
        <!-- A Few Words About Us-->
        <section class="section-90 section-md-111 text-left">
          <div class="shell">
            <div class="range range-xs-center">
              
                <div class="inset-lg-right-20">
                  <h2 class="text-bold text-center text-md-left">A Few Words About Us</h2>
                  <hr class="divider hr-md-left-0 bg-chathams-blue">
                  <div class="offset-top-30 offset-md-top-60">
                    <p>The transport sector of the country is one of the key areas through which a nation’s growth towards development can be assessed. The countries who have developed and enhanced means of transportation within their major cities have seen some exceptional economic growth. Passenger convenience is certainly one of the key features to ensure an effective transport system. 
The existing ticketing and bus systems in our country do not provide convenient transportation to everyday commuters even in today’s era where smart technology has reached out to common people through smartphones and web services, we have still not been able to implement such a system where all the stages of travel, beginning from ticket booking to arrival at the destination, are all integrated within single platform.
Cameras will scan faces of boarding passengers and counting number of passengers will give the stat like survey to introduce new services or improving the existing one. E-Booking and schedule will also be provided by the system moreover for ease of customer exchange and refund. Smartness will also provide by tracking the vehicle(GPS) and will inform driver that how much time left to reach destination and manages his/her speed according to that and user also can see the remaining time of vehicle to reach that point from where his/her journey begin. System will also have enough info about other buses coming on that route and their seat availability on that particular point (We assume here integrated companies will share seat availability on point bases based on MOU) and adjust the passengers in that buses in case of any incident which cause the failure of that vehicle to move.
  
</p>
                    </div>
                  </div>
                </div>
              </div>
             
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <!-- Page Footer-->
      <!-- Footer Default-->
</html>    