	</div>
</body>



<div class='container'>
	<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		<ul class="nav navbar-nav">
			<li><h3>&copy; All Rights Reserved By </h3><img  src='<?php echo PATH; ?>images/logo-dark1.png' alt=''/><h4>2016-<?php echo date("Y"); ?></h4></li>
		</ul>
	</div>
</div>
</html>